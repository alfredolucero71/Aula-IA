require('dotenv').config();
const express=require('express');
const app=express();
app.get('/api/status',(q,s)=>s.json({ok:true}));
app.listen(process.env.PORT||3000,()=>console.log('OK'));

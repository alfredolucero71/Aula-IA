Estructura base.
